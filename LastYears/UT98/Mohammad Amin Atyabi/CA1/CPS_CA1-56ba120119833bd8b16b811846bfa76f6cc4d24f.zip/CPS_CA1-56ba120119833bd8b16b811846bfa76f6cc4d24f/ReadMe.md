**Protheus Library Link**

Copy These Files In Proteus Installation/DATA/Library
- [Arduino](https://content.instructables.com/FKD/Z0O4/IT22WQPK/FKDZ0O4IT22WQPK.rar)  
- [BlueTooth](https://content.instructables.com/FKD/Z0O4/IT22WQPK/FKDZ0O4IT22WQPK.rar)

Virtual Port Emulator To Connect Bluetooth Devices . Install [VSPD](https://www.virtual-serial-port.org)

Add These Two Pairs :
- COM3 - COM4
- COM8 - COM9

**BUILD ALL CODES USING**

```sh
./build.bat
```

Run simulation/CPS-CA1.pdsprj With proteus

DONE!
