# Pong

**Useful resources**

- [https://developer.android.com/jetpack/compose/graphics/draw/overview](https://developer.android.com/jetpack/compose/graphics/draw/overview)
- [https://semicolonspace.com/draw-circle-jetpack-compose-canvas](https://semicolonspace.com/draw-circle-jetpack-compose-canvas/)



https://user-images.githubusercontent.com/35252268/235374762-8f0986d4-3b80-45fc-8d40-8b2612dc5fd5.mp4
